import React from 'react';
import CreateBook from './components/CreateBook';

const App = () => {
    return (
        <div>
            <h1>Book Manager</h1>
            <CreateBook />
        </div>
    );
};

export default App;
